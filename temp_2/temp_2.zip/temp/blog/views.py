from django.shortcuts import render
from django.http import  HttpResponse
from django.shortcuts import render_to_response

def index(request):
    return  HttpResponse("I ankit here")

def home(request):
    return render_to_response(
        'blog.html',
        {'user': request.user}
    )

def contact(request):
    return render_to_response(
        'contact.html',
        {'user': request.user}
    )
